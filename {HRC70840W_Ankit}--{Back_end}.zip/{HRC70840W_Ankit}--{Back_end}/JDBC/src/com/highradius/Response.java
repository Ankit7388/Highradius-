package com.highradius;

//POJO class

public class Response {
	private int id;
	private String businessCode;
	private int CustomerNumber;
	private String clearDate;
	private int businessYear;
	private String docID;
	private String postingDate;
	private String documentcreateDate;
	private String documentcreateDate1;
	private String dueinDate;
	private String invoiceCurrency;
	private String documentType;
	private int postingID;
	private double totalopenAmount;
	private String baselinecreateDate;
	private String custpaymentTerms;
	private int invoiceID;
	private short isOpen;
	
	//Getters and Setters
	public int getID() {
		return id;
	}
	public void setID(int ID) {
		this.id = ID;
	}
	public String getBusinessCode() {
		return businessCode;
	}
	public void setBusinessCode(String businessCode) {
		this.businessCode = businessCode;
	}
	public int getCustomerNumber() {
		return CustomerNumber;
	}
	public void setCustomerNumber(int customerNumber) {
		CustomerNumber = customerNumber;
	}
	public String getClearDate() {
		return clearDate;
	}
	public void setClearDate(String clearDate) {
		this.clearDate = clearDate;
	}
	public int getBusinessYear() {
		return businessYear;
	}
	public void setBusinessYear(int businessYear) {
		this.businessYear = businessYear;
	}
	public String getDocID() {
		return docID;
	}
	public void setDocID(String docID) {
		this.docID = docID;
	}
	public String getPostingDate() {
		return postingDate;
	}
	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}
	public String getDocumentcreateDate() {
		return documentcreateDate;
	}
	public void setDocumentcreateDate(String documentcreateDate) {
		this.documentcreateDate = documentcreateDate;
	}
	public String getDocumentcreateDate1() {
		return documentcreateDate1;
	}
	public void setDocumentcreateDate1(String documentcreateDate1) {
		this.documentcreateDate1 = documentcreateDate1;
	}
	public String getDueinDate() {
		return dueinDate;
	}
	public void setDueinDate(String dueinDate) {
		this.dueinDate = dueinDate;
	}
	public String getInvoiceCurrency() {
		return invoiceCurrency;
	}
	public void setInvoiceCurrency(String invoiceCurrency) {
		this.invoiceCurrency = invoiceCurrency;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public int getPostingID() {
		return postingID;
	}
	public void setPostingID(int postingID) {
		this.postingID = postingID;
	}
	public double getTotalopenAmount() {
		return totalopenAmount;
	}
	public void setTotalopenAmount(double totalopenAmount) {
		this.totalopenAmount = totalopenAmount;
	}
	public String getBaselinecreateDate() {
		return baselinecreateDate;
	}
	public void setBaselinecreateDate(String baselinecreateDate) {
		this.baselinecreateDate = baselinecreateDate;
	}
	public String getCustpaymentTerms() {
		return custpaymentTerms;
	}
	public void setCustpaymentTerms(String custpaymentTerms) {
		this.custpaymentTerms = custpaymentTerms;
	}
	public int getInvoiceID() {
		return invoiceID;
	}
	public void setInvoiceID(int invoiceID) {
		this.invoiceID = invoiceID;
	}
	public short getIsOpen() {
		return isOpen;
	}
	public void setIsOpen(short isOpen) {
		this.isOpen = isOpen;
	}
	
}

