import React, { useState, useEffect } from "react";
import { DataGrid } from "@material-ui/data-grid";
import { makeStyles } from "@material-ui/core";
import axios from "axios";

const useStyles = makeStyles((theme) => ({
  MuiDataGridRoot: {
    color: '#fff',
    backgroundColor: 'var(--color-bg-variant)',
  }
}));

const MyAPI = axios.create ({
  baseURL: "http://localhost:8080/backend/DataLoading"
})

const columns = [
  { field: "slno", headerAlign: "center", headerName: "sl no"},
  {
    field: "businessCode",
    headerAlign: "center",
    headerName: "business Code",
    width: 200,
  },
  {
    field: "CustomerNumber",
    headerAlign: "center",
    headerName: "Customer Number",
    width: 200,
  },
  {
    field: "clearDate",
    headerAlign: "center",
    headerName: "Clear Date",
    width: 200,
  },
  {
    field: "businessYear",
    headerAlign: "center",
    headerName: "Business Year",
    width: 200,
  },
  { field: "docID", headerAlign: "center", headerName: "Document ID", width: 200 },
  {
    field: "postingDate",
    headerAlign: "center",
    headerName: "Posting Date",
    width: 200,
  },
  {
    field: "documentcreateDate",
    headerAlign: "center",
    headerName: "Document Create Date",
    width: 200,
  },
  {
    field: "dueinDate",
    headerAlign: "center",
    headerName: "Due Date",
    width: 200,
  },
  {
    field: "invoiceCurrency",
    headerAlign: "center",
    headerName: "Invoice Currency",
    width: 200,
  },
  {
    field: "documentType",
    headerAlign: "center",
    headerName: "Document Type",
    width: 200,
  },
  {
    field: "postingID",
    headerAlign: "center",
    headerName: "Posting ID",
    width: 200,
  },
  {
    field: "totalopenAmount",
    headerAlign: "center",
    headerName: "Total Open Amount",
    width: 200,
  },
  {
    field: "baselinecreateDate",
    headerAlign: "center",
    headerName: "Baseline Create Date",
    width: 200,
  },
];

const DataTable = ({rowData}) => {
  const classes = useStyles();
  const [rows, setRows] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const response = await MyAPI.get()
      setRows(response.data)
    }
    fetchData();
  }, []);

  return (
    <div style={{ height: 300, width: "100%" }}>
      <DataGrid
        pageSize={5}
        className={classes.MuiDataGridRoot}
        rows={rows}
        getRowId={(row) => row.slno}
        columns={columns}
        checkboxSelection
        onSelectionModelChange={(ids) => {
          const selectedIds = new Set(ids);
          const selectedRowData = rows.filter((row) =>
            selectedIds.has(row.slno));
            rowData(selectedRowData);
        }}
        rowHeight={30}
        rowsPerPageOptions={[5, 25, 100]}
        pagination
      />
    </div>
  );
};

export default DataTable;
