import React from 'react'
import TextField from "@material-ui/core/TextField";
import './addPopUp.css'

function AddPopUp() {

  return (
    <div className='Grid__container'>
    <TextField className='Grid__item' label='BuisnessCode' variant="outlined" />
    <TextField className='Grid__item' label='Customer Number' variant="outlined" />
    <TextField className='Grid__item' label="Clear Date" type="date" defaultValue="2017-05-24" variant="outlined" />
    <TextField className='Grid__item' label='Buisness Year' variant="outlined" />
    <TextField className='Grid__item' label='Document Id' variant="outlined" />
    <TextField className='Grid__item' label='Posting Date' type="date" defaultValue="2017-05-24" variant="outlined" />
    <TextField className='Grid__item' label='Document Create Date' type="date" defaultValue="2017-05-24" variant="outlined" />
    <TextField className='Grid__item' label='Due Date' type="date" defaultValue="2017-05-24" variant="outlined" />
    <TextField className='Grid__item' label='Invoice Currency' variant="outlined" />
    <TextField className='Grid__item' label='Document Type' variant="outlined" />
    <TextField className='Grid__item' label='Posting Id' variant="outlined" />
    <TextField className='Grid__item' label='Total Open Amount' variant="outlined" />
    <TextField className='Grid__item' label='Baseline Create Date' type="date" defaultValue="2017-05-24" variant="outlined" />
    <TextField className='Grid__item' label='Customer Payment Terms' variant="outlined" />
    <TextField className='Grid__item' label='Invoice Id' variant="outlined" />
    </div>
  )
}

export default AddPopUp